import pandas as pd
import geopandas as gpd
import numpy as np
import plotly.express as px
from plotly.subplots import make_subplots
import plotly.graph_objects as go
import pyproj
import logging
from Toolbox.filter_functions import get_config
from Toolbox.get_data_of_interest import normalize_line


logging.basicConfig( format = "%(asctime)s - %(message)s")

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def get_map_object(fp, regionalized_clusters=['AT', 'DE']):
    """loads a shapefile, simplifies it and transforms it into a, for plotly, usable format
    Parameters
    ----------
    # CODEREVIEW: filepath may be different in deployed version
    fp : string (i.e. ".\shape_nuts2.shx")
        fp defines a shapefile location in unicode
    regionalized_clusters: List of Countries that are regionalized. Default is set to ['AT', 'DE']
    
    Returns
    -------
    geopandas.geodataframe.GeoDataFrame
    -------


    @author: johannes.misensky
    """
    #read in file
    map_df = gpd.read_file(fp)
    #Returns a GeoSeries containing a simplified representation of each geometry
    # map_df["geometry"] = (
    #     map_df.to_crs(map_df.estimate_utm_crs()).simplify(1000).to_crs(map_df.crs)
    # )
    #transform to readable geo-df
    map_df["geometry"] = map_df["geometry"].simplify(0.01)
    map_df.to_crs(pyproj.CRS.from_epsg(4326), inplace=True)
    # Change CountryID for AT and DE 
    for country in range(len(map_df.COUNTRY_ID)):
        if map_df.COUNTRY_ID[country] in regionalized_clusters:
            map_df.COUNTRY_ID[country]= map_df.COUNTRY_ID[country] + '_' + str(map_df.id[country])
    return(map_df)


def plot_grid(result_path, normal, retro, dc, carrier, year, button, map_df, title_dict,map_color_dict, df_carrier_max, divisor = 1e3, min_line_kap_to_plot = 0.1,  max_lines_width = 40 ):
    """Plots a Geo. Figure in Plotly containing all clusters and a given grid
    Parameters
    ----------
    normal : Dataframe containing Links and Buses for AC and H2/gas grid, should be provided by get_grid_df function
    retro : Dataframe containing Links and Buses for retrofitted H2 grid, should be provided by get_grid_df function
    carrier : string (== "gas pipeline", "AC", "H2 pipeline")
        carrier (e.g. "gas pipeline", "AC") used to differenciate what grid to plot
    divisor : Variable to divde Capacity and therefore line thickness. Default set to 1e3
    min_line_kap_to_plot : threshold for minimum Capacity to be plotted. Default set to 0.1
    df_carrier_max: dictionary
        Max Value of each grid carrier per year
    max_lines_width: Float
        Max width of a plotted line. Default set to 40
    Returns
    -------
    Choropleth map : Grid plot of a given carrier
    -------


    @author: johannes.misensky
    """ 
    # dictionary for styled line Tags
    marker_dict = dict(
                     color='rgb(229,236,246)',
                     size=25,
                     opacity=0.8,
                     line=dict(
                         color='rgb(229,236,246)',
                         width=2,
                     
                     )
                 )
    
    #newly build h2 piplines are plotted with dots
    if carrier == "H2 pipeline":
        Lines_type ='dot'
    else:
        Lines_type = None

    #plot a choropleth map
    fig = px.choropleth(map_df, geojson=map_df.geometry, 
                    locations=map_df.index, color =map_df.index ,  
                    height=500, 
                    # Colorscale atm set to one color
                    color_continuous_scale=map_color_dict["color_continuous_scale"],
                    hover_name =  list(map_df.COUNTRY_ID) )
    
    for trace in fig.data:
        trace.update(marker_opacity=1)
        
    fig.for_each_trace(lambda trace: trace.update(marker_line_color="white"))
    
    # mapbox_layout = go.Layout(
    #     mapbox_style="open-street-map",  # Use the OpenStreetMap style
    #     mapbox_center={"lat": 51, "lon": 10},  # Center the map on a specific location
    #     mapbox_zoom=5,  # Set the initial zoom level
    # )
 
    # # Create the figure and set the Mapbox layout
    # fig = go.Figure(layout=mapbox_layout)

    # Formate hover_name to only show the Country ID = Cluster name
    fig.update_traces(customdata= np.stack(map_df.COUNTRY_ID, axis=0),
        hovertemplate = '<b>%{customdata}</b>' )

    #Plot grid lines and set width, AC has to be treated specially 
    if carrier == 'AC':

        for i in range(len(normal.lines.s_nom_opt)):
            fig.add_trace(
                go.Scattergeo(
                    lon = [normal.buses.loc[normal.lines.bus0[i]]['x'].round(3), normal.buses.loc[normal.lines.bus1[i]]['x'].round(3)],
                    lat = [normal.buses.loc[normal.lines.bus0[i]]['y'].round(3), normal.buses.loc[normal.lines.bus1[i]]['y'].round(3)],
                    mode = 'lines',
                    line = dict(width = normalize_line(normal.lines.s_nom_opt[i],df_carrier_max.loc[carrier][year], max_lines_width),color =  map_color_dict[carrier][0]), #s_nom_opt nur Termische Kap = s_nom_opt * s_max_pu for net
                    hoverinfo = 'none',
                    name="{} GW AC-Grid".format(int(round((normal.lines.s_nom_opt[i])/divisor))) 
                )
            )
            # plots a Tag with AC Capacity in middle of line. +0.05 so Tags arent above DC Tags
            if (normal.lines.s_nom_opt[i])/divisor > min_line_kap_to_plot:
                fig.add_trace(go.Scattergeo(
                    lon =[0.5*(normal.buses.loc[normal.lines.bus0[i]]['x'].round(3)+normal.buses.loc[normal.lines.bus1[i]]['x'].round(3))+0.05], 
                    lat = [0.5*(normal.buses.loc[normal.lines.bus0[i]]['y'].round(3)+normal.buses.loc[normal.lines.bus1[i]]['y'].round(3))+0.05], 
                    marker= marker_dict,
                    mode='markers+text', 
                    hoverinfo = 'none',
                    text="<b>{}<b>".format((normal.lines.s_nom_opt[i]/divisor).round(1))))
        
        #plot dc lines     
        for i in range(len(dc.links.p_nom_opt)):
            fig.add_trace(
                go.Scattergeo(
                    lon = [normal.buses.loc[normal.links.bus0[i]]['x'].round(3), normal.buses.loc[normal.links.bus1[i]]['x'].round(3)],
                    lat = [normal.buses.loc[normal.links.bus0[i]]['y'].round(3), normal.buses.loc[normal.links.bus1[i]]['y'].round(3)],
                    mode = 'lines',
                    line = dict(width = normalize_line(dc.links.p_nom_opt[i],df_carrier_max.loc[carrier][year], max_lines_width),color =  map_color_dict[carrier][1]),
                    hoverinfo = 'none',
                    opacity = 0.5,
                    name="{} GW DC-Grid".format(int(round(dc.links.p_nom_opt[i]/divisor)))
                )
            )
            # plots a Tag with DC Capacity in middle of line
            if (dc.links.p_nom_opt[i]/divisor) > min_line_kap_to_plot:
                fig.add_trace(go.Scattergeo(
                        lon =[0.5*(normal.buses.loc[normal.links.bus0[i]]['x'].round(3)+normal.buses.loc[normal.links.bus1[i]]['x'].round(3))], 
                        lat = [0.5*(normal.buses.loc[normal.links.bus0[i]]['y'].round(3)+normal.buses.loc[normal.links.bus1[i]]['y'].round(3))], 
                        marker= marker_dict,
                        mode='markers+text',
                        hoverinfo = 'none',
                        text="<b>{}<b>".format((dc.links.p_nom_opt[i]/divisor).round(1)), 
                        textfont=dict(color = 'peru')),
                      )
    

    elif carrier == "gas pipeline":
        
        for i in range(len(normal.links.p_nom)):
            fig.add_trace(
                go.Scattergeo(
                    lon = [normal.buses.loc[normal.links.bus0[i]]['x'].round(3), normal.buses.loc[normal.links.bus1[i]]['x'].round(3)],
                    lat = [normal.buses.loc[normal.links.bus0[i]]['y'].round(3), normal.buses.loc[normal.links.bus1[i]]['y'].round(3)],
                    mode = 'lines',
                    line = dict(width = normalize_line(normal.links.p_nom[i],df_carrier_max.loc[carrier][year], max_lines_width),color = map_color_dict[carrier][0],dash=Lines_type),
                    hoverinfo = 'none',
                    name="{} GW Methane Pipeline".format(int(round(normal.links.p_nom[i]/divisor)))

                )
            )
            if (normal.links.p_nom_opt[i]/divisor) > min_line_kap_to_plot:
                fig.add_trace(go.Scattergeo(
                        lon =[0.5*(normal.buses.loc[normal.links.bus0[i]]['x'].round(3)+normal.buses.loc[normal.links.bus1[i]]['x'].round(3))+0.1],
                        lat = [0.5*(normal.buses.loc[normal.links.bus0[i]]['y'].round(3)+normal.buses.loc[normal.links.bus1[i]]['y'].round(3))+0.1],
                        marker=marker_dict,
                        mode='markers+text',
                        hoverinfo = 'none',
                        text="<b>{}<b>".format((normal.links.p_nom[i]/divisor).round(1)), 
                        textfont=dict(color = 'black')),
                      )
        

    else:
        # newly Build H2
        
        for i in range(len(normal.links.p_nom_opt)):
            fig.add_trace(
                go.Scattergeo(
                    lon = [normal.buses.loc[normal.links.bus0[i]]['x'].round(3), normal.buses.loc[normal.links.bus1[i]]['x'].round(3)],
                    lat = [normal.buses.loc[normal.links.bus0[i]]['y'].round(3), normal.buses.loc[normal.links.bus1[i]]['y'].round(3)],
                    mode = 'lines',
                    line = dict(width = normalize_line(normal.links.p_nom_opt[i],df_carrier_max.loc[carrier + ' retrofit'][year], max_lines_width),color = map_color_dict[carrier][0],dash=Lines_type),
                    hoverinfo = 'none',
                    name="{} GW Hydrogen Pipeline".format(int(round(normal.links.p_nom_opt[i]/divisor)))

                )
            )
            if (normal.links.p_nom_opt[i]/divisor) > min_line_kap_to_plot:
                fig.add_trace(go.Scattergeo(
                        lon =[0.5*(normal.buses.loc[normal.links.bus0[i]]['x'].round(3)+normal.buses.loc[normal.links.bus1[i]]['x'].round(3))+0.1],
                        lat = [0.5*(normal.buses.loc[normal.links.bus0[i]]['y'].round(3)+normal.buses.loc[normal.links.bus1[i]]['y'].round(3))+0.1],
                        marker=marker_dict,
                        mode='markers+text',
                        hoverinfo = 'none',
                        text="<b>{}<b>".format((normal.links.p_nom_opt[i]/divisor).round(1)), 
                        textfont=dict(color = 'black')),
                      )
        #plots Retrofitted Hydrogen Lines
        for i in range(len(retro.links.p_nom_opt)):
            fig.add_trace(
                go.Scattergeo(
                    lon = [normal.buses.loc[retro.links.bus0[i]]['x'].round(3), normal.buses.loc[retro.links.bus1[i]]['x'].round(3)],
                    lat = [normal.buses.loc[retro.links.bus0[i]]['y'].round(3), normal.buses.loc[retro.links.bus1[i]]['y'].round(3)],
                    mode = 'lines',
                    line = dict(width = normalize_line(retro.links.p_nom_opt[i],df_carrier_max.loc[carrier + ' retrofit'][year], max_lines_width),color = map_color_dict[carrier][1]),
                    hoverinfo = 'none',
                    name="{} GW retrofitted Hydrogen Pipeline".format(int(round(retro.links.p_nom_opt[i]/divisor)))
                )
            )
            
            if (retro.links.p_nom_opt[i]/divisor) > min_line_kap_to_plot:
                fig.add_trace(go.Scattergeo(
                lon =[0.5*(normal.buses.loc[retro.links.bus0[i]]['x'].round(3)+normal.buses.loc[retro.links.bus1[i]]['x'].round(3))], 
                lat = [0.5*(normal.buses.loc[retro.links.bus0[i]]['y'].round(3)+normal.buses.loc[retro.links.bus1[i]]['y'].round(3))], 
                marker=marker_dict,
                mode='markers+text',
                hoverinfo = 'none',
                text="<b>{}<b>".format((retro.links.p_nom_opt[i]/divisor).round(1)), 
                textfont=dict(color = '#3A566E'))
              )


    #centralize on europe

    if button == 'europe':
        fig.update_geos(
            visible=False, resolution=50, 
            scope="europe",
            lataxis_range=[35, 60], lonaxis_range=[-10, 30],
            showcountries=True, countrycolor="white",
            showcoastlines=True, coastlinecolor="white",
            showland=True, landcolor="white",
            showocean=True, oceancolor="#243845",
            showlakes=False, lakecolor="#00464f",
            showrivers=False, rivercolor="#00464f"
        )
    else:
        #zoom to AT
        fig.update_geos(
            visible=False, resolution=50, 
            scope="europe",
            #center around AT
            center=dict(lon=11, lat=40), 
            projection_rotation=dict(lon=30.5, lat=30.5, roll=30.5),  
            lataxis_range=[10,11], lonaxis_range=[33,41],
            showcountries=True, countrycolor="white",
            showcoastlines=True, coastlinecolor="white",
            showland=True, landcolor="white",
            showocean=True, oceancolor="#243845",
            showlakes=False, lakecolor="#00464f",
            showrivers=False, rivercolor="#00464f"
        )
    
    #Scale Figure 
    fig.update_layout(
        title=f"{title_dict[carrier]} Grid Capacity in GW in {year}",
        autosize=False,
        width=1200,
        height=1200,
        coloraxis_showscale=False,

    )

    #the following part is only for legend customizing

    #create empty list to store legend labels
    labels_to_show_in_legend = []

    #as far as i understand plotly needs a geoobject to exist in the plot to be filtered in legend 
    #therefor find the closest existing Capacity to 3 and 10 GW and store them in List
    
    s =3
    if carrier == 'AC':
        a = int(round(min(dc.links.p_nom_opt/divisor, key=lambda x:abs(x-s))))
        labels_to_show_in_legend.append("{} GW DC-Grid".format(a))
        b = int(round(min((normal.lines.s_nom_opt * normal.lines.s_max_pu)/divisor, key=lambda x:abs(x-s))))
        labels_to_show_in_legend.append("{} GW AC-Grid".format(b))
    elif carrier == 'gas pipeline':
        c = int(round(min(normal.links.p_nom_opt/divisor, key=lambda x:abs(x-s))))
        labels_to_show_in_legend.append("{} GW Methane Pipeline".format(c))
    else:
        c = int(round(min(normal.links.p_nom_opt/divisor, key=lambda x:abs(x-s))))
        labels_to_show_in_legend.append("{} GW Hydrogen Pipeline".format(c))
        d = int(round(min(retro.links.p_nom_opt/divisor, key=lambda x:abs(x-s))))
        labels_to_show_in_legend.append("{} GW retrofitted Hydrogen Pipeline".format(d))

    #create empty set
    labels = set()

    #check if trace name is not in set and in list, if true enable showlegend and store in set
    for trace in fig['data']: 
        if ( not trace['name'] in labels) and (trace['name'] in labels_to_show_in_legend):
            labels.add(trace['name'])
            trace['name'] = trace['name'][4:]
            trace['showlegend'] = True
            #print(trace['name'])   #enable print for troubleshooting
        else:
            trace['showlegend'] = False
            
    note = 'Line Capacity below {} GW is not plotted'.format(min_line_kap_to_plot)
    if carrier == 'AC':
        note += '<br>The displayed grid capacity refers to the current limit. The available transmission capacity with<br> the model is calculated as 70% of the thermal current limit to ensure n-1 security.'
    
    lines = note.count('<br>')

    fig.add_annotation(
    text=note,
    xref="paper",
    yref="paper",
    xanchor="left",
    yanchor="top",
    x=0,
    y=-0.17,
    showarrow=False,
    font = {"size":10},
    align="left"
    )

    fig.update_layout(
            margin={"b":125 + 50*lines}
        )
    



    return(fig)

