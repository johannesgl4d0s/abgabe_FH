import pandas as pd
from typing import Tuple


def get_map_color_dict():
    """
   Returns
   -------
   map_color_dict : Dict
       color dictionary for grid lines
   """
    map_color_dict = {"gas pipeline":["#63A452"],
    "H2 pipeline" : ['#258994', "#258994"], "AC": ['#D90429','#E19990'], 
    #"color_continuous_scale" : [[0, 'rgb(229,236,246)'], [0.05, 'rgb(229,236,246)'],[0.1, 'rgb(229,236,246)'],[0.20, 'rgb(229,236,246)'],[1, 'rgb(229,236,246)']]
    "color_continuous_scale" : [[0, '#e6d9cf'], [0.05, '#e6d9cf'],[0.1, '#e6d9cf'],[0.20, '#e6d9cf'],[1, '#e6d9cf']]
    }
    return map_color_dict