import pandas as pd
import numpy as np
import plotly.express as px
import json
import os
import time
import logging
from os import walk
from os import system
from openpyxl import Workbook
from openpyxl.chart import BarChart, Series, Reference


def export_fig_to_html(figure_name, year, region, figure, result_path):
    """
    Exports plotly figure as html in with the file name "{figure_name}_{year}_{region}.html" in the folder "Graphs" at result_path
    
    Parameters
    ----------
    figure_name: str
        defining name of the html
    year: str
        part of the exportet file name
    region: str
        part of the exportet file name
    figure: plotly figure
        the plotly figure to export
    result_path: path/str
        path where the "Graph" folder should be, usually ends in "\evaluation"        
    """   
    if not os.path.exists(os.path.join(result_path,"Graphs")):
        os.makedirs(os.path.join(result_path,"Graphs"))

    # Ordneraddresse festlegen
    if year:
        figure.write_html(os.path.join(result_path, "Graphs", f"{figure_name}_{year}_{region}.html"))
    else:
        figure.write_html(os.path.join(result_path, "Graphs", f"{figure_name}_{region}.html"))
    
