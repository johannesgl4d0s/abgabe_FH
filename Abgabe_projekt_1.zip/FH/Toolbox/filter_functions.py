import pandas as pd
import pypsa
import yaml
from typing import Tuple, Union, Dict
import numpy as np
from pathlib import Path



def get_config(result_path: str) -> dict:
    """
    function for fetching the config_customize.yaml 

    Parameters
    ----------
    result_path:        str             path to results (ends with /esm_run)
    
    Returns
    -------
    config:             dict            pypsa config as dictionary
    -------
    Created on 14.07.2023

    @author: Moritz Wenclawiak
    """
    with open(Path(result_path) / "configs" / "config_customize.yaml") as stream:
        try:
        # Converts yaml document to python object
            config=yaml.safe_load(stream)
        except yaml.YAMLError as e:
            logger.info(e)
    return config
