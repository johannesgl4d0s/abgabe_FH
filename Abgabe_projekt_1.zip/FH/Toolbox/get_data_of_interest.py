import logging
import pandas as pd
import numpy as np
import pypsa
import yaml
from pathlib import Path
import os




logging.basicConfig( format = "%(asctime)s - %(message)s")

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def get_grid_df(n,carrier):
    """Gets all capacity dataframes for the grid
    Parameters
    ----------
    n : Networks
    carrier : string (== "gas pipeline", "AC", "H2 pipeline")
        carrier (e.g. "gas pipeline", "DC") used in lines and links for transporting a specific energy
    
    Returns
    -------
    three dataframes:
    normal = classic grid, including newly build H2 grid
    dc = dc Grid
    retro only used for H2 retrofitted piplines.
    -------
    Created on 20.04.2023

    @author: johannes.misensky
    """
    normal = n.copy()
    retro = n.copy()
    dc = n.copy()
    if carrier == 'AC':
        normal.lines = n.lines[n.lines.type =="Al/St 240/40 4-bundle 380.0"]
        dc.links = n.links[n.links.carrier == "DC"]
        for bus in normal.buses[n.buses.carrier=="AC"].index:
            dc.buses.loc[f"{bus}", ["x","y"]] = normal.buses.loc[bus, ["x","y"]]
    else: 
        normal.links = n.links[(n.links.carrier == carrier)]
        carrier_retro = carrier + " retrofit"
        retro.links = n.links[(n.links.carrier == carrier_retro)]
        for bus in normal.buses[n.buses.carrier=="AC"].index:
            normal.buses.loc[f"{bus}"+ " "  + carrier[:3].strip(), ["x","y"]] = normal.buses.loc[bus, ["x","y"]]
            retro.buses.loc[f"{bus}"+ " " + carrier[:3].strip(), ["x","y"]] = retro.buses.loc[bus, ["x","y"]]
    return(normal,retro,dc)


def df_max_carrier(networks, carriers =["Al/St 240/40 4-bundle 380.0","DC", "gas pipeline","H2 pipeline","H2 pipeline retrofit"]):

    
    """
    Generates a dataframe of  the max capacity for each carrier per year
    Parameters
    ----------
    networks: pypsa.Network
        Network from which the data is analysied
    carriers: List
        List of all carriers. Default set to all grid based carriers 

    Returns
    -------
    Dataftame
        Returns a dataframe (Columns = Years, Index = Carrier)

    """

    dict_carrier_max = {}

    for year, i in networks.items():
        n = networks[year]
        for carrier in carriers:
            if carrier == "Al/St 240/40 4-bundle 380.0":
                if year in dict_carrier_max.keys():
                    dict_carrier_max[year].append(max(n.lines[n.lines.type ==carrier]['s_nom_opt']))
                else:
                    dict_carrier_max[year] = [max(n.lines[n.lines.type ==carrier]['s_nom_opt'])]
            else:
                if year in dict_carrier_max.keys():
                    dict_carrier_max[year].append(max(n.links[n.links.carrier == carrier]['p_nom_opt']))
                else:
                    dict_carrier_max[year] = max(n.links[n.links.carrier == carrier]['p_nom_opt'])

    if "Al/St 240/40 4-bundle 380.0" in carriers:
        i = carriers.index("Al/St 240/40 4-bundle 380.0")
        carriers[i] = 'AC'

    df = pd.DataFrame(dict_carrier_max, index= carriers)

    return df

def normalize_line(value, Max, factor= 40):
    """
    Normalizes a given Value around a local Maximum and multiplies by a factor

    Parameters
    ----------
    value : float
        Value the will be normaized.
    Max : Float
        Maximum of a given range.
    factor : float
        Max amount to mupliply values. Default set to 40

    Returns
    -------
    Float
        Returns a normalized float values.

    """

    if Max == 0: 
        return 0 # zero divided by zero equals inf, which can be problematic. 
    else:

        return abs((value/Max))*factor
