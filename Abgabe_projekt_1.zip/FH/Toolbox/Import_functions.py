import pypsa
import pandas as pd
import os
from os import walk
from pathlib import Path



def get_networks(scenario_path, file_name = "postnetworks"):
    """
    reads result postnetworks into a dictionary; the result network for a specific year is calles with networks["2020"]
    all information listet in components can be found in the structure (see: https://pypsa.readthedocs.io/en/latest/components.html)

    Parameters
    ----------
    scenario_path : str
        path to the run that should be analyzed (ends with "\esm_run")
    file_name : str
        joins szenario_path and file_name to path to networks. Default set to "postnetworks".
  
    Returns
    -------
    networks : Dict
        dictionary that contains pypsa.Network for every year for wich postnetworks were calculated
    planning_horizon : List
        list with all years for wich postnetworks were calculated in the specific run
    """
    
    scenario_path = os.path.join(os.path.normpath(scenario_path) , file_name)
    filenames = os.listdir(scenario_path)

    networks = {}
    planning_horizon = []
    for file in filenames:
        year = file[-7:-3]
        networks[year] = pypsa.Network(os.path.join(scenario_path,file))
        planning_horizon.append(year)
        
    return networks, planning_horizon
