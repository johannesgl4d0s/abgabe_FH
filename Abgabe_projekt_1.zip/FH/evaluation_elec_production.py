import pypsa
import pandas as pd
import numpy as np
import time
import sys
import os
from openpyxl import Workbook
from openpyxl.chart import BarChart, Series, Reference

from Toolbox.get_data_of_interest import get_elec_amounts_data
from Toolbox.get_style_dictionaries import get_rename_region_dict, get_APG_color_scheme, get_regional_dict, get_filter_dictionaries
from Toolbox.plot_functions import  dataframe_to_plotly
from Toolbox.Import_functions import get_networks, get_regional_industry_demand_files
from Toolbox.export_functions import export_fig_to_html, export_fig_to_json, export_filters_to_json
from Toolbox.filter_functions import mapping_int_ext



def main(result_path, networks, years, regional=["AT"], language = "EN"):
    # result_path should end in \esm_run
    evaluation_path = os.path.join(result_path,"evaluation")

    region_dict = get_regional_dict()
    only_regions, all_regions = get_rename_region_dict(language_parameter=language)
    AT_regions = region_dict["AT"]
    countries = [x for x in all_regions.keys() if (len(x)==2) & (x !="EU")]
    # get data for prod and demand:
    industry_demand = get_regional_industry_demand_files(result_path)
    elec_amounts=get_elec_amounts_data(networks, years, regional = ["AT"],industry_demand=industry_demand)
    results_dict={}
    for region in elec_amounts.keys():
        results_dict[region]=pd.concat(elec_amounts[region].values(),axis=1,keys=elec_amounts[region].keys())

        # mapping elec production:
    elec_prod_excel, elec_prod_plotly = mapping_int_ext(results_dict,"elec_prod",language)
    # mapping elec demand:
    elec_demand_excel, elec_demand_plotly = mapping_int_ext(results_dict,"elec_demand",language)

    # plolty color scheme
    col_mapp =get_APG_color_scheme(component="color_dict_elec_capas")
    # Since the colors are saved without # we have to add #
    col_mapp_hex = {key: "#" + col_mapp[key] for key in col_mapp.keys()}

    # ========================================== Power Production Quanities Export ==============================================

    # ==================================== Export: Excel ====================================
    excel_export_dict={
        "file_name" : "Stromerzeugung_EU",
        "file_name_regions": "Stromerzeugung_AT",
        "excel_color" : "color_dict_elec_capas",
        "axis_titles": ["Jahre","TWH"],
        "filter_component" : ["elec_prod"]
    }


    # ==================================== Export: Plotly ====================================


    if language =="DE":
        title = "Stromerzeugung "
        plot_dict={
            "title": title,  "unit": "TWh","legend_title":"Energy Carrier",
            # "footnote": footnote,
        }
        shape_dict={"Import Ausland" : "/","Import Inland": "/"}
        #sort in column from top to bottom
        sort_array=["Import Ausland","Import Inland","Photovoltaik","Windkraft","Wasserkraft","Biomasse","Wasserstoff","Thermische Kraftwerke","Kernenergie","Sonstige"]
    else:
        title = "Power Production total incl. Import "
        plot_dict={
            "title": title,  "unit": "TWh","legend_title":"Energy Carrier",
        }
        shape_dict={"Import Foreign" : "/","Import Domestic": "/"}
        #sort in column from top to bottom
        sort_array=["Import Foreign","Import Domestic","V2G Discharge","Pumped Hydro Storage","Photovoltaics","Wind Power","Hydropower","Biomass","Hydrogen","Thermal Powerplants","Nuclear Power","Miscellaneous"]

    remove_columns=["2015"]

    # plolty export
    for region in elec_prod_plotly.keys():
        title_region = title + all_regions[region] + " in " + plot_dict["unit"]
        plot_dict["title"]=title_region
        file_name = "elec_production"
        plotly_fig = dataframe_to_plotly(elec_prod_plotly[region], plot_dict,
                                         factor=1, color_dict = col_mapp_hex, shape_dict=shape_dict,
                                         cut_off=0.05, sort_array=sort_array, remove_columns=remove_columns)
        export_fig_to_html(file_name,"",region,plotly_fig,evaluation_path)
        export_fig_to_json(file_name,"",region,plotly_fig,evaluation_path)







    # ==================================== Export: Plotly ====================================



    if language =="DE":
        title = "Energie Nachfrage "
        plot_dict={
            "title": title,  "unit": "TWh","legend_title":"Energy Carrier",
            # "footnote": footnote,
        }
        shape_dict={"Export Ausland" : "/","Export Inland": "/"}
        #sort in column from top to bottom
        sort_array=["Import Ausland","Import Inland","Photovoltaik","Windkraft","Wasserkraft","Biomasse","Wasserstoff","Thermische Kraftwerke","Kernenergie","Sonstige"]
    else:
        title = "Power Demand "
        plot_dict={
            "title": title,  "unit": "TWh","legend_title":"Energy Consumer",
            # "footnote": footnote,
        }
        shape_dict={"Export Foreign" : "/","Export Domestic": "/"}
        #sort in column from top to bottom
        sort_array=["Export Foreign" , "Export Domestic" , "Pumped Hydro Storage", "V2G Charger" , "Battery Storage", "Electrolysis",
                    "Wärme - Heat Pump" , "Wärme - Resitive Heater" , "Road Freight", "Passenger Transport", "Electrif. Industry", "Industry", "Households & Services"]


    remove_columns=["2015"]

    # plolty export
    for region in elec_demand_plotly.keys():
        title_region = title + all_regions[region]
        plot_dict["title"]=title_region
        file_name = "elec_demand"
        plotly_fig = dataframe_to_plotly(elec_demand_plotly[region], plot_dict,
                                         factor=1, color_dict = col_mapp_hex, shape_dict=shape_dict,
                                         cut_off=0.0001, sort_array=sort_array, remove_columns=remove_columns)
        export_fig_to_html(file_name,"",region,plotly_fig,evaluation_path)
        export_fig_to_json(file_name,"",region,plotly_fig,evaluation_path)



    # ========================================== Power Balance ==============================================
    power_balance_excel={}
    for key in elec_prod_excel.keys():
        tmp = pd.concat([elec_prod_excel[key],-elec_demand_excel[key]])
        drop_list=[ x for x in ["V2G Discharge","Battery Storage","V2G Charger", "Battery Discharge"] if x in tmp.index]
        power_balance_excel[key]= tmp.drop(drop_list)


    power_balance_ploty={}
    for key in elec_prod_plotly.keys():
        tmp = pd.concat([elec_prod_plotly[key],-elec_demand_plotly[key]])
        drop_list=[ x for x in ["V2G Discharge","Battery Storage","V2G Charger", "Battery Discharge"] if x in tmp.index]
        power_balance_ploty[key]= tmp.drop(drop_list)



    if language =="DE":
        title = "Energie Bilanz "
        plot_dict={
            "title": title,  "unit": "TWh","legend_title":"Energy Carrier", "legend_font_size": 16,
            # "footnote": footnote,
        }
        shape_dict={"Export Ausland" : "/","Export Inland": "/"}
        #sort in column from top to bottom
        sort_array=["Import Ausland","Import Inland","Photovoltaik","Windkraft","Wasserkraft","Biomasse","Wasserstoff","Thermische Kraftwerke","Kernenergie","Sonstige"]
    else:
        title = "Power Balance "
        plot_dict={
            "title": title,  "unit": "TWh","legend_title":"Category", "legend_font_size": 16,
            "footnote": "Balance does not include grid losses and losses due to storage technologies.",
        }
        shape_dict={"Export Foreign" : "/","Export Domestic": "/", "Import Foreign" : "/","Import Domestic": "/"}
        #sort in column from top to bottom
        sort_array=["Import Foreign","Import Domestic","Run-of-River", "Inflow Hydro Storage", "Wind Power","Photovoltaics",
                    "Thermal Powerplants", "Biomass", "Hydrogen", "Nuclear Power", "Miscellaneous",
                    "Export Foreign","Export Domestic" , "Transport", "District Heat" , "Decentral Heat" , "Electrolysis",
                    "Direct Air Capture", "Households & Services", "Industry",
                    # "Industry", "Households & Services", "Decentral Heat" , "District Heat" , "Transport"
                    #  "Electrolysis","Direct Air Capture", "Export Domestic" ,"Export Foreign" ,
                    ]
    remove_columns=["2015"]

    # plolty export
    for region in power_balance_ploty.keys():
        title_region = title + all_regions[region] + " in " + plot_dict["unit"]
        plot_dict["title"]=title_region
        file_name = "elec_balance"
        plotly_fig = dataframe_to_plotly(power_balance_ploty[region], plot_dict,
                                         factor=1, color_dict = col_mapp_hex, shape_dict=shape_dict,
                                         cut_off=0.0001, sort_array=sort_array, remove_columns=remove_columns, barmode="relative")
        export_fig_to_html(file_name,"",region,plotly_fig,evaluation_path)
        export_fig_to_json(file_name,"",region,plotly_fig,evaluation_path)



    return results_dict