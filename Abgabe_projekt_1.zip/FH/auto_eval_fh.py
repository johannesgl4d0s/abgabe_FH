# -*- coding: utf-8 -*-
"""


@author: johannes.misensky
"""
from plot_map_fh import main as map_main
mypath = r"C:\Users\johannes.misensky\OneDrive - AGGM\Dokumente\ESM_Aus\FH\test_15"
export_path = r"C:\Users\johannes.misensky\OneDrive - AGGM\Dokumente\ESM_Aus\FH"


map_main(mypath, export_path) 