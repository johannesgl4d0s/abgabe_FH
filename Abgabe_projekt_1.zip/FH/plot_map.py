import logging
import os.path as path
from Toolbox.get_data_of_interest import get_grid_df, df_max_carrier
from Toolbox.plot_functions import get_map_object, plot_grid 
from Toolbox.get_style_dictionaries import get_map_color_dict
from Toolbox.export_functions import export_fig_to_html
from Toolbox.Import_functions import get_networks
from Toolbox.filter_functions import get_config
logging.basicConfig( format = "%(asctime)s - %(message)s")

logger = logging.getLogger()
logger.setLevel(logging.INFO)





def main(result_path , evaluation_path, carrier = ["gas pipeline", "AC", "H2 pipeline"]):
    """plots several maps as json and pngs as well as 3 filter jsons
    Parameters
    ----------
    export_path : string - path to where the generated json and png should be saved (=="\ESM_Aus\eval_auto_test")
    evaluation_path : string - path to postnetwork files (=="\ESM_Aus\postnetworks")
    planning_horizon: list of years to iterate over    
    carrier : List of Carriers to plot. Default set to ["gas pipeline", "AC", "H2 pipeline"]

    Returns
    -------
    jsons, htmls and pngs as well as 3 filter jsons
    -------
    Created on 20.04.2023

    @author: johannes.misensky
    
    """
    #path to shapefiles path.abspath(path.join(__file__ ,"../..")) + '/pypsa-eur/split/AT10/AT10.shx'
    fp = '.\shapefile\shapes_AT10.shx'
    map_df = get_map_object(fp)
    map_color_dict = get_map_color_dict()
    
    config = get_config(r'C:\Users\johannes.misensky\OneDrive - AGGM\Dokumente\ESM_Aus\postnetworks')
    opts = config["scenario"]["sector_opts"][0].split("-", 10)
    retrofit = config['sector']['h2_retrofit']

    if "noH2network" in opts and not retrofit:
        carrier = ["gas pipeline", "AC"]
        
        carrier_max = ["Al/St 240/40 4-bundle 380.0","DC", "gas pipeline"]
        logging.info('no H2, no retro')
    elif "noH2network" in opts:
        carrier_max = ["Al/St 240/40 4-bundle 380.0","DC", "gas pipeline","H2 pipeline retrofit"]
        logging.info('no H2')
    elif not retrofit:
        carrier_max = ["Al/St 240/40 4-bundle 380.0","DC", "gas pipeline","H2 pipeline"]
        logging.info(' no retro')
    else:
        carrier_max = ["Al/St 240/40 4-bundle 380.0","DC", "gas pipeline","H2 pipeline","H2 pipeline retrofit"]
        logging.info('both')
    
    
        
        

    networks, planning_horizon = get_networks(result_path)
    df_carrier_max = df_max_carrier(networks, carrier_max)
    logging.info(df_carrier_max)
    

    # Quick and dirty solution to change to carriers to the naming convention of LearnConsult
    title_dict = {"gas pipeline":"Methane Transmission",
         "AC":"Power Transmission",
         "H2 pipeline":"Hydrogen Transmission",
         "europe":"EU",
         "AT":"AT"}
    #this part plots htmls, png and jsons of every carrier, every year, for europe or AT     
    #this solution should be optimised in the futur
    radio = 'europe'
    
    for c in carrier:
        
        for year in planning_horizon:
            n = networks[year]
            #get_grid_df is need because normal is a df for either ac, gas or newly build h2
            normal,retro,dc = get_grid_df(n,c)
            fig = plot_grid(result_path, normal, retro, dc, c, year, radio, map_df,title_dict,map_color_dict, df_carrier_max)

            export_fig_to_html(figure_name=title_dict[c].replace(" ", ""), year = year, region=title_dict[radio], figure=fig,result_path= r"C:\Users\johannes.misensky\OneDrive - AGGM\Dokumente\ESM_Aus\postnetworks")
            logging.info('Doing stuff')
                
        
    

   
if __name__  == "__plot_map__":
    main(result_path , evaluation_path, planning_horizon, networks)

        